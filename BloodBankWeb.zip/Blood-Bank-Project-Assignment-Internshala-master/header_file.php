<!DOCTYPE HTML>
<html>
<head>
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="style/style.css" />
</head>
<body>
  <div id="main">
    <div id="header">
      <div id="logo">
        <div id="logo_text">
          <h1><a href="index.php">LIVE_<span class="logo_colour">HEALTHY</span></a></h1>
          <h2>BLOOD BANK MANAGEMENT PORTAL</h2>
        </div>
      </div>
      <div id="menubar">
        <ul id="menu">